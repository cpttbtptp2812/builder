const KEYS = ["skilltap"];

const emptyState = () => ({
  recording: false,
  tabId: null,
  startUrl: "",
  name: "",
  description: "",
  rawSteps: [],
  steps: [],
  startedAt: 0,
});

async function loadState() {
  const { skilltap } = await chrome.storage.session.get("skilltap");
  return skilltap && typeof skilltap === "object" ? { ...emptyState(), ...skilltap } : emptyState();
}

async function saveState(next) {
  await chrome.storage.session.set({ skilltap: next });
  return next;
}

function restricted(url) {
  return !url || /^(chrome|edge|about|devtools|chrome-extension):/i.test(url);
}

async function setBadge(on) {
  await chrome.action.setBadgeText({ text: on ? "REC" : "" });
  if (on) await chrome.action.setBadgeBackgroundColor({ color: "#be123c" });
}

async function inject(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["selector.js", "content.js"],
    });
    return true;
  } catch {
    return false;
  }
}

async function ping(tabId) {
  try {
    return await chrome.tabs.sendMessage(tabId, { type: "skilltap-ping" });
  } catch {
    return null;
  }
}

async function ensureInjected(tabId) {
  const live = await ping(tabId);
  if (live?.ok) return true;
  return inject(tabId);
}

async function setRecordingOnTab(tabId, recording) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "skilltap-set", recording });
    return true;
  } catch {
    return false;
  }
}

async function startRecording(tab) {
  if (!tab?.id || restricted(tab.url)) {
    return { ok: false, error: "当前页不能录制（浏览器内部页 / 扩展商店）" };
  }
  const ok = await ensureInjected(tab.id);
  if (!ok) return { ok: false, error: "无法注入此页面，请刷新后再试" };

  const prev = await loadState();
  const state = {
    ...prev,
    recording: true,
    tabId: tab.id,
    startUrl: tab.url || "",
    rawSteps: [],
    steps: [],
    startedAt: Date.now(),
  };
  await saveState(state);
  await setRecordingOnTab(tab.id, true);
  await setBadge(true);
  return { ok: true, state };
}

async function stopRecording() {
  const state = await loadState();
  if (state.tabId) {
    await setRecordingOnTab(state.tabId, false);
  }
  const next = { ...state, recording: false };
  await saveState(next);
  await setBadge(false);
  return { ok: true, state: next };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    if (msg?.type === "skilltap-get") {
      sendResponse({ ok: true, state: await loadState() });
      return;
    }
    if (msg?.type === "skilltap-save-meta") {
      const state = await loadState();
      const next = {
        ...state,
        name: msg.name ?? state.name,
        description: msg.description ?? state.description,
      };
      await saveState(next);
      sendResponse({ ok: true, state: next });
      return;
    }
    if (msg?.type === "skilltap-start") {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      sendResponse(await startRecording(tab));
      return;
    }
    if (msg?.type === "skilltap-stop") {
      sendResponse(await stopRecording());
      return;
    }
    if (msg?.type === "skilltap-toggle") {
      const state = await loadState();
      if (state.recording) {
        sendResponse(await stopRecording());
        return;
      }
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      sendResponse(await startRecording(tab));
      return;
    }
    if (msg?.type === "skilltap-pause") {
      const state = await loadState();
      const step = {
        action: "pause",
        reason: msg.reason || "登录 / 验证码 / 等人处理",
        ts: Date.now(),
        url: state.startUrl,
      };
      const next = {
        ...state,
        rawSteps: [...state.rawSteps, step],
        steps: [...state.steps, step],
      };
      await saveState(next);
      sendResponse({ ok: true, state: next });
      return;
    }
    if (msg?.type === "skilltap-remove") {
      const state = await loadState();
      const steps = state.steps.filter((_, i) => i !== msg.index);
      const next = { ...state, steps };
      await saveState(next);
      sendResponse({ ok: true, state: next });
      return;
    }
    if (msg?.type === "skilltap-replace-steps") {
      const state = await loadState();
      const next = { ...state, steps: Array.isArray(msg.steps) ? msg.steps : state.steps };
      await saveState(next);
      sendResponse({ ok: true, state: next });
      return;
    }
    if (msg?.type === "skilltap-clear") {
      const next = emptyState();
      await saveState(next);
      await setBadge(false);
      sendResponse({ ok: true, state: next });
      return;
    }
    if (msg?.type === "skilltap-step") {
      const state = await loadState();
      if (!state.recording) {
        sendResponse({ ok: false });
        return;
      }
      if (state.tabId && sender.tab?.id && sender.tab.id !== state.tabId) {
        sendResponse({ ok: false });
        return;
      }
      const rawSteps = [...state.rawSteps, msg.step];
      const next = { ...state, rawSteps, steps: rawSteps };
      await saveState(next);
      sendResponse({ ok: true });
      return;
    }
  })();
  return true;
});

chrome.tabs.onUpdated.addListener(async (tabId, info) => {
  const state = await loadState();
  if (!state.recording || state.tabId !== tabId) return;
  if (info.status === "complete") {
    await ensureInjected(tabId);
    await setRecordingOnTab(tabId, true);
  }
});

chrome.tabs.onRemoved.addListener(async (tabId) => {
  const state = await loadState();
  if (state.tabId === tabId && state.recording) {
    await stopRecording();
  }
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command !== "toggle-record") return;
  const state = await loadState();
  if (state.recording) {
    await stopRecording();
    return;
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  await startRecording(tab);
});

void KEYS;
