(function (root, factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.SkillTapClean = api;
})(typeof self !== "undefined" ? self : globalThis, function () {
  const DROP = new Set(["hover", "mousemove", "mouseover", "mouseout", "pointerenter", "pointerleave", "scroll"]);

  function sameTarget(a, b) {
    if (!a || !b) return false;
    if (a.selector && b.selector && a.selector === b.selector) return true;
    if (a.role && a.name && a.role === b.role && a.name === b.name) return true;
    return false;
  }

  function originOf(step) {
    if (step?.url) {
      try {
        return new URL(step.url).origin + new URL(step.url).pathname;
      } catch {
        return step.url;
      }
    }
    return "";
  }

  function cleanSteps(steps) {
    const list = Array.isArray(steps) ? steps.slice() : [];
    const out = [];

    for (const raw of list) {
      if (!raw || DROP.has(raw.action)) continue;
      const step = { ...raw };
      let last = out[out.length - 1];

      if (step.action === "fill" && last?.action === "click" && sameTarget(last, step)) {
        out.pop();
        last = out[out.length - 1];
      }

      if (step.action === "fill" && last?.action === "fill" && sameTarget(last, step)) {
        last.value = step.value;
        last.secret = Boolean(step.secret);
        last.ts = step.ts;
        continue;
      }

      if (
        step.action === "click" &&
        last?.action === "click" &&
        sameTarget(last, step) &&
        typeof step.ts === "number" &&
        typeof last.ts === "number" &&
        step.ts - last.ts < 450
      ) {
        continue;
      }

      if (step.action === "goto") {
        if (last?.action === "goto" && last.url === step.url) continue;
        if (last?.action === "click" && last.href && last.href === step.url) continue;
        if (last && originOf(last) === step.url) continue;
      }

      if (
        step.action === "submit" &&
        last?.action === "click" &&
        (last.type === "submit" || last.tag === "button" || last.role === "button")
      ) {
        continue;
      }

      if (step.action === "click" && (step.tag === "html" || step.tag === "body")) continue;

      out.push(step);
    }

    if (out.length && out[0].action !== "goto") {
      const url = out.find((s) => s.url)?.url;
      if (url) {
        out.unshift({
          action: "goto",
          url,
          ts: (out[0].ts || Date.now()) - 1,
        });
      }
    }

    return out;
  }

  function slugify(name) {
    const s = String(name || "")
      .trim()
      .toLowerCase()
      .replace(/[\s_]+/g, "-")
      .replace(/[^a-z0-9-]/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 64);
    return s || "recorded-skill";
  }

  function summarize(step) {
    if (step.action === "goto") return `打开 ${step.url || ""}`;
    if (step.action === "pause") return `暂停：${step.reason || "等人处理"}`;
    if (step.action === "fill") {
      if (step.secret) return `填写 ${step.name || step.selector}（密文，需人手输入）`;
      return `填写 ${step.name || step.selector} = ${String(step.value ?? "").slice(0, 40)}`;
    }
    if (step.action === "select") return `选择 ${step.name || step.selector} = ${step.value || ""}`;
    if (step.action === "submit") return `提交表单 ${step.name || step.selector || ""}`.trim();
    if (step.action === "click") {
      const label = step.name || step.selector || step.tag || "元素";
      return `点击 ${label}`;
    }
    return step.action;
  }

  return { cleanSteps, slugify, summarize, DROP };
});
