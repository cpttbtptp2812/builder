(function (root, factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.SkillTapPack = api;
})(typeof self !== "undefined" ? self : globalThis, function () {
  function getClean() {
    const g = typeof globalThis !== "undefined" ? globalThis : {};
    return (
      g.SkillTapClean || {
        slugify(name) {
          const s = String(name || "")
            .trim()
            .toLowerCase()
            .replace(/[\s_]+/g, "-")
            .replace(/[^a-z0-9-]/g, "-")
            .replace(/-+/g, "-")
            .replace(/^-|-$/g, "")
            .slice(0, 64);
          return s || "recorded-skill";
        },
        summarize(step) {
          return step?.action || "";
        },
      }
    );
  }

  function yamlEscape(text) {
    return String(text || "")
      .replace(/\r?\n/g, " ")
      .replace(/"/g, '\\"')
      .slice(0, 1024);
  }

  function buildSkillMd({ name, description, steps }) {
    const Clean = getClean();
    const lines = steps.map((step, i) => `${i + 1}. ${Clean.summarize(step)}`);
    const hasPause = steps.some((s) => s.action === "pause" || s.secret);
    return `---
name: ${name}
description: "${yamlEscape(description)}"
---

# ${name}

This skill was recorded with 录技 (SkillTap). Replay the browser flow in \`steps.json\`.

## When to use

${description}

## How to run

From this skill directory:

\`\`\`bash
npm i playwright
npx playwright install chromium
node scripts/replay.mjs
\`\`\`

If Playwright is not available, execute each step in order with browser tools (open URL, click, fill). Prefer \`role\` + \`name\`; fall back to \`selector\`.

${hasPause ? "## Human-in-the-loop\n\nSteps with `action: pause` or `secret: true` require the user (login, captcha, password, file picker). Do not invent credentials. Wait until they finish, then continue.\n" : ""}
## Recorded steps

${lines.join("\n")}

## Files

- \`steps.json\` — machine-readable actions
- \`scripts/replay.mjs\` — Playwright runner (headed Chromium)
`;
  }

  function buildReplayScript() {
    return `#!/usr/bin/env node
/**
 * Replay a SkillTap recording with Playwright.
 *   npm i playwright
 *   npx playwright install chromium
 *   node scripts/replay.mjs
 */
import { createInterface } from "node:readline";
import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { chromium } from "playwright";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const pack = JSON.parse(readFileSync(join(root, "steps.json"), "utf8"));
const steps = Array.isArray(pack.steps) ? pack.steps : pack;

async function waitUser(reason) {
  const rl = createInterface({ input: process.stdin, output: process.stdout });
  await new Promise((resolve) => {
    rl.question(\`\\n[暂停] \${reason}\\n完成后按回车继续… \`, () => resolve());
  });
  rl.close();
}

async function locate(page, step) {
  if (step.role && step.name) {
    const byRole = page.getByRole(step.role, { name: step.name });
    if ((await byRole.count()) > 0) return byRole.first();
  }
  if (step.selector) return page.locator(step.selector).first();
  throw new Error("no locator: " + JSON.stringify(step));
}

const browser = await chromium.launch({ headless: false });
const page = await browser.newPage();

try {
  for (const step of steps) {
    if (step.action === "goto") {
      await page.goto(step.url, { waitUntil: "domcontentloaded" });
      continue;
    }
    if (step.action === "pause") {
      await waitUser(step.reason || "需要人工处理");
      continue;
    }
    if (step.action === "fill") {
      if (step.secret || step.value === "") {
        await waitUser("请填写密文/密码：" + (step.name || step.selector || ""));
        continue;
      }
      const loc = await locate(page, step);
      await loc.fill(String(step.value ?? ""));
      continue;
    }
    if (step.action === "select") {
      const loc = await locate(page, step);
      await loc.selectOption(String(step.value ?? ""));
      continue;
    }
    if (step.action === "submit") {
      const loc = await locate(page, step);
      await Promise.all([
        page.waitForLoadState("domcontentloaded").catch(() => {}),
        loc.evaluate((el) => {
          if (el instanceof HTMLFormElement) el.requestSubmit();
          else el.click();
        }),
      ]);
      continue;
    }
    if (step.action === "click") {
      const loc = await locate(page, step);
      await loc.click();
    }
  }
  await waitUser("回放结束，确认结果后按回车关闭浏览器");
} finally {
  await browser.close();
}
`;
  }

  function buildPack({ name, description, steps, recordedAt }) {
    const Clean = getClean();
    const slug = Clean.slugify(name);
    const desc =
      description?.trim() ||
      `Replays a recorded browser workflow (${slug}). Use when the user asks to repeat this page flow.`;
    const payload = {
      name: slug,
      description: desc,
      recordedAt: recordedAt || new Date().toISOString(),
      tool: "skilltap",
      version: "1.0.0",
      steps,
    };
    return {
      slug,
      files: [
        { name: "SKILL.md", text: buildSkillMd({ name: slug, description: desc, steps }) },
        { name: "steps.json", text: JSON.stringify(payload, null, 2) + "\n" },
        { name: "scripts/replay.mjs", text: buildReplayScript() },
      ],
    };
  }

  return { buildPack, buildSkillMd, buildReplayScript };
});
