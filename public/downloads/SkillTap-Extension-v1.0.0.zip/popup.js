const nameEl = document.getElementById("name");
const descEl = document.getElementById("desc");
const toggleEl = document.getElementById("toggle");
const pauseEl = document.getElementById("pause");
const exportEl = document.getElementById("export");
const clearEl = document.getElementById("clear");
const listEl = document.getElementById("list");
const countEl = document.getElementById("count");
const msgEl = document.getElementById("msg");
const pillEl = document.getElementById("rec-pill");

let state = null;
let savingMeta = 0;

function send(msg) {
  return chrome.runtime.sendMessage(msg);
}

function setMsg(text, err) {
  msgEl.textContent = text || "";
  msgEl.className = err ? "msg err" : "msg";
}

function render(next) {
  state = next;
  if (document.activeElement !== nameEl) nameEl.value = next.name || "";
  if (document.activeElement !== descEl) descEl.value = next.description || "";

  const rec = Boolean(next.recording);
  pillEl.textContent = rec ? "录制中" : "待机";
  pillEl.className = rec ? "pill on" : "pill off";
  toggleEl.textContent = rec ? "停止" : "开始录制";
  toggleEl.classList.toggle("stop", rec);

  const steps = Array.isArray(next.steps) ? next.steps : [];
  countEl.textContent = `${steps.length} 步`;
  exportEl.disabled = steps.length === 0;

  listEl.innerHTML = "";
  if (!steps.length) {
    const empty = document.createElement("li");
    empty.className = "empty";
    empty.textContent = rec ? "正在听点击和输入…" : "还没有步骤。打开要自动化的网页再开始。";
    listEl.appendChild(empty);
    return;
  }

  steps.forEach((step, index) => {
    const li = document.createElement("li");
    const n = document.createElement("span");
    n.className = "n";
    n.textContent = String(index + 1);
    const body = document.createElement("span");
    body.className = step.action === "pause" ? "act-pause" : step.action === "goto" ? "act-goto" : "";
    body.textContent = SkillTapClean.summarize(step);
    const del = document.createElement("button");
    del.type = "button";
    del.className = "del";
    del.textContent = "×";
    del.title = "删除这步";
    del.addEventListener("click", async () => {
      const res = await send({ type: "skilltap-remove", index });
      if (res?.state) render(res.state);
    });
    li.append(n, body, del);
    listEl.appendChild(li);
  });
}

async function persistMeta() {
  clearTimeout(savingMeta);
  savingMeta = window.setTimeout(() => {
    send({
      type: "skilltap-save-meta",
      name: nameEl.value.trim(),
      description: descEl.value.trim(),
    });
  }, 200);
}

nameEl.addEventListener("input", persistMeta);
descEl.addEventListener("input", persistMeta);

toggleEl.addEventListener("click", async () => {
  setMsg("");
  const type = state?.recording ? "skilltap-stop" : "skilltap-start";
  const res = await send({ type });
  if (!res?.ok) {
    setMsg(res?.error || "操作失败", true);
    return;
  }
  let next = res.state;
  if (type === "skilltap-stop") {
    const cleaned = SkillTapClean.cleanSteps(next.steps || next.rawSteps || []);
    const saved = await send({ type: "skilltap-replace-steps", steps: cleaned });
    next = saved?.state || { ...next, steps: cleaned };
    setMsg(`已清洗为 ${cleaned.length} 步，可删改后再导出`);
  }
  render(next);
});

pauseEl.addEventListener("click", async () => {
  const reason = window.prompt("暂停原因（登录 / 验证码 / 选文件）", "登录 / 验证码") || "登录 / 验证码";
  const res = await send({ type: "skilltap-pause", reason });
  if (res?.state) render(res.state);
});

clearEl.addEventListener("click", async () => {
  const res = await send({ type: "skilltap-clear" });
  if (res?.state) render(res.state);
  setMsg("");
});

exportEl.addEventListener("click", async () => {
  if (!state?.steps?.length) return;
  await send({
    type: "skilltap-save-meta",
    name: nameEl.value.trim(),
    description: descEl.value.trim(),
  });
  const pack = SkillTapPack.buildPack({
    name: nameEl.value.trim() || "recorded-skill",
    description: descEl.value.trim(),
    steps: state.steps,
    recordedAt: new Date().toISOString(),
  });
  const bytes = SkillTapZip.pack(pack.files);
  const blob = new Blob([bytes], { type: "application/zip" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `${pack.slug}.zip`;
  a.click();
  URL.revokeObjectURL(url);
  setMsg(`已下载 ${pack.slug}.zip → 解压到 ~/.cursor/skills/${pack.slug}/`);
});

chrome.storage.session.onChanged.addListener((changes, area) => {
  if (area !== "session" || !changes.skilltap) return;
  const next = changes.skilltap.newValue;
  if (next) render(next);
});

send({ type: "skilltap-get" }).then((res) => {
  render(res?.state || { recording: false, steps: [], name: "", description: "" });
});
