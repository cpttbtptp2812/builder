const nameEl = document.getElementById("name");
const descEl = document.getElementById("desc");
const toggleEl = document.getElementById("toggle");
const pauseEl = document.getElementById("pause");
const exportEl = document.getElementById("export");
const previewEl = document.getElementById("preview");
const clearEl = document.getElementById("clear");
const listEl = document.getElementById("list");
const countEl = document.getElementById("count");
const msgEl = document.getElementById("msg");
const pillEl = document.getElementById("rec-pill");

let state = null;
let savingMeta = 0;

function send(msg) {
  return chrome.runtime.sendMessage(msg);
}

function setMsg(text, err) {
  msgEl.textContent = text || "";
  msgEl.className = err ? "msg err" : "msg";
}

function render(next) {
  state = next;
  if (document.activeElement !== nameEl) nameEl.value = next.name || "";
  if (document.activeElement !== descEl) descEl.value = next.description || "";

  const rec = Boolean(next.recording);
  pillEl.textContent = rec ? "录制中" : "待机";
  pillEl.className = rec ? "pill on" : "pill off";
  toggleEl.textContent = rec ? "停止" : "开始录制";
  toggleEl.classList.toggle("stop", rec);

  const steps = Array.isArray(next.steps) ? next.steps : [];
  countEl.textContent = `${steps.length} 步`;
  exportEl.disabled = steps.length === 0 || rec;
  previewEl.disabled = steps.length === 0 || rec;

  listEl.innerHTML = "";
  if (!steps.length) {
    const empty = document.createElement("li");
    empty.className = "empty";
    empty.textContent = rec ? "正在记录你的点击和填写…" : "还没有步骤。打开要教别人的网页，再点开始录制。";
    listEl.appendChild(empty);
    return;
  }

  steps.forEach((step, index) => {
    const li = document.createElement("li");
    const n = document.createElement("span");
    n.className = "n";
    n.textContent = String(index + 1);
    const body = document.createElement("span");
    body.className = step.action === "pause" ? "act-pause" : step.action === "goto" ? "act-goto" : "";
    body.textContent = SkillTapClean.summarize(step);
    const del = document.createElement("button");
    del.type = "button";
    del.className = "del";
    del.textContent = "×";
    del.title = "删除这步";
    del.addEventListener("click", async () => {
      const res = await send({ type: "skilltap-remove", index });
      if (res?.state) render(res.state);
    });
    li.append(n, body, del);
    listEl.appendChild(li);
  });
}

async function persistMeta() {
  clearTimeout(savingMeta);
  savingMeta = window.setTimeout(() => {
    send({
      type: "skilltap-save-meta",
      name: nameEl.value.trim(),
      description: descEl.value.trim(),
    });
  }, 200);
}

async function currentPack() {
  await send({
    type: "skilltap-save-meta",
    name: nameEl.value.trim(),
    description: descEl.value.trim(),
  });
  const shotRes = await send({ type: "skilltap-shots" });
  return SkillTapPack.buildPack({
    name: nameEl.value.trim() || "操作手册",
    description: descEl.value.trim(),
    steps: state.steps,
    shots: shotRes?.shots || {},
    recordedAt: new Date().toISOString(),
  });
}

nameEl.addEventListener("input", persistMeta);
descEl.addEventListener("input", persistMeta);

toggleEl.addEventListener("click", async () => {
  setMsg("");
  const type = state?.recording ? "skilltap-stop" : "skilltap-start";
  const res = await send({ type });
  if (!res?.ok) {
    setMsg(res?.error || "操作失败", true);
    return;
  }
  let next = res.state;
  if (type === "skilltap-stop") {
    const cleaned = SkillTapClean.cleanSteps(next.steps || next.rawSteps || []);
    const saved = await send({ type: "skilltap-replace-steps", steps: cleaned });
    next = saved?.state || { ...next, steps: cleaned };
    setMsg(`整理成 ${cleaned.length} 步。先点预览，确认后再发给别人。`);
  }
  render(next);
});

pauseEl.addEventListener("click", async () => {
  const reason = window.prompt("这一步对方要自己做的事", "登录 / 验证码") || "登录 / 验证码";
  const res = await send({ type: "skilltap-pause", reason });
  if (res?.state) render(res.state);
});

clearEl.addEventListener("click", async () => {
  const res = await send({ type: "skilltap-clear" });
  if (res?.state) render(res.state);
  setMsg("");
});

previewEl.addEventListener("click", async () => {
  if (!state?.steps?.length) return;
  await send({
    type: "skilltap-save-meta",
    name: nameEl.value.trim(),
    description: descEl.value.trim(),
  });
  const res = await send({ type: "skilltap-preview" });
  if (!res?.ok) setMsg("无法打开预览", true);
  else setMsg("已在新标签打开手册，可点「演示一遍」");
});

exportEl.addEventListener("click", async () => {
  if (!state?.steps?.length) return;
  const pack = await currentPack();
  const blob = new Blob([pack.html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = pack.filename;
  a.click();
  URL.revokeObjectURL(url);
  setMsg(`已下载「${pack.filename}」。发给同事，用浏览器打开即可。`);
});

chrome.storage.session.onChanged.addListener((changes, area) => {
  if (area !== "session" || !changes.skilltap) return;
  const next = changes.skilltap.newValue;
  if (next) render(next);
});

send({ type: "skilltap-get" }).then((res) => {
  render(res?.state || { recording: false, steps: [], name: "", description: "" });
});
