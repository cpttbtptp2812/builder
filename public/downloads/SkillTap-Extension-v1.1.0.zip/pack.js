(function (root, factory) {
  const api = factory();
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.SkillTapPack = api;
})(typeof self !== "undefined" ? self : globalThis, function () {
  function getClean() {
    return (typeof globalThis !== "undefined" && globalThis.SkillTapClean) || {
      fileTitle: () => "操作手册.html",
      instruct: () => ({ title: "操作", body: "", link: "" }),
    };
  }

  function esc(text) {
    return String(text ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function buildManualHtml({ name, description, steps, shots, recordedAt }) {
    const Clean = getClean();
    const title = String(name || "").trim() || "操作手册";
    const intro = String(description || "").trim() || "按下面的步骤做即可。点右上角「演示一遍」会自动翻页讲解。";
    const when = recordedAt
      ? new Date(recordedAt).toLocaleString("zh-CN", { hour12: false })
      : "";
    const shotMap = shots && typeof shots === "object" ? shots : {};

    const cards = steps.map((step, i) => {
      const info = Clean.instruct(step);
      const img = shotMap[String(step.ts)] || shotMap[step.ts] || "";
      const x = Number(step.xPct);
      const y = Number(step.yPct);
      const pin =
        Number.isFinite(x) && Number.isFinite(y)
          ? `<i class="pin" style="left:${x}%;top:${y}%"></i>`
          : "";
      const link = info.link
        ? `<p class="go"><a href="${esc(info.link)}" target="_blank" rel="noreferrer">打开这个网址</a></p>`
        : "";
      const figure = img
        ? `<div class="shot">${pin}<img src="${img}" alt="第 ${i + 1} 步截图" /></div>`
        : `<div class="shot empty">这一步没有截到图，按文字说明操作即可。</div>`;
      return `<article class="card" id="s${i}" data-i="${i}">
  <span class="num">${i + 1}</span>
  <div>
    <h2>${esc(info.title)}</h2>
    <p>${esc(info.body)}</p>
    ${link}
    ${figure}
  </div>
</article>`;
    });

    const demo = steps.map((step) => {
      const info = Clean.instruct(step);
      return {
        title: info.title,
        body: info.body,
        link: info.link || "",
        shot: shotMap[String(step.ts)] || shotMap[step.ts] || "",
        xPct: step.xPct,
        yPct: step.yPct,
      };
    });

    return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>${esc(title)}</title>
  <style>
    :root { --ink:#1c1410; --paper:#f6f0e6; --line:#e7dcc8; --red:#be123c; --muted:#7c6a58; }
    * { box-sizing: border-box; }
    body { margin: 0; background: var(--paper); color: var(--ink); font: 16px/1.6 "PingFang SC","Microsoft YaHei",Georgia,serif; }
    .wrap { max-width: 760px; margin: 0 auto; padding: 2rem 1.25rem 4rem; }
    header { border-bottom: 2px solid var(--ink); padding-bottom: 1rem; margin-bottom: 1.25rem; }
    .kicker { letter-spacing: 0.18em; font-size: 0.72rem; color: var(--red); font-weight: 700; }
    h1 { margin: 0.2rem 0 0.4rem; font-size: 1.8rem; }
    .intro { margin: 0; color: var(--muted); }
    .meta { margin: 0.5rem 0 0; font-size: 0.78rem; color: var(--muted); }
    .toolbar { display: flex; gap: 0.5rem; flex-wrap: wrap; margin: 1rem 0 1.5rem; }
    button, .toolbar a {
      font: inherit; border-radius: 999px; padding: 0.45rem 0.9rem; cursor: pointer;
      border: 1.5px solid var(--ink); background: var(--ink); color: var(--paper); text-decoration: none;
    }
    button.ghost, .toolbar a.ghost { background: transparent; color: var(--ink); }
    .card { display: grid; grid-template-columns: 2.4rem 1fr; gap: 0.7rem; margin: 0 0 1.4rem; }
    .num {
      width: 2rem; height: 2rem; border-radius: 50%; border: 1.5px solid var(--ink);
      display: grid; place-items: center; font-weight: 700; font-size: 0.85rem;
    }
    h2 { margin: 0 0 0.25rem; font-size: 1.05rem; }
    .card p { margin: 0 0 0.45rem; }
    .go a { color: var(--red); }
    .shot { position: relative; border: 1px solid var(--line); background: #fff; border-radius: 0.4rem; overflow: hidden; }
    .shot img { display: block; width: 100%; }
    .shot.empty { padding: 1.2rem; color: var(--muted); font-size: 0.9rem; }
    .pin {
      position: absolute; width: 18px; height: 18px; margin: -9px 0 0 -9px; border-radius: 50%;
      background: var(--red); box-shadow: 0 0 0 6px rgba(190,18,60,0.28); pointer-events: none;
    }
    .foot { margin-top: 2rem; font-size: 0.78rem; color: var(--muted); border-top: 1px solid var(--line); padding-top: 0.8rem; }
    #stage {
      display: none; position: fixed; inset: 0; background: rgba(28,20,16,0.92); color: #f6f0e6;
      z-index: 9; flex-direction: column; padding: 1rem;
    }
    #stage.on { display: flex; }
    #stage .frame { flex: 1; display: grid; place-items: center; min-height: 0; }
    #stage .pic { position: relative; display: inline-block; max-width: 100%; }
    #stage img { display: block; max-width: 100%; max-height: 70vh; border-radius: 0.4rem; background: #000; }
    #stage .empty { opacity: 0.7; }
    #stage .pin { z-index: 2; }
    #stage .cap { text-align: center; padding: 0.8rem; }
    #stage .cap strong { display: block; font-size: 1.1rem; margin-bottom: 0.2rem; }
    #stage .bar { display: flex; justify-content: center; gap: 0.5rem; padding-bottom: 0.6rem; }
    #stage button { background: #f6f0e6; color: #1c1410; }
  </style>
</head>
<body>
  <div class="wrap">
    <header>
      <p class="kicker">操作手册</p>
      <h1>${esc(title)}</h1>
      <p class="intro">${esc(intro)}</p>
      ${when ? `<p class="meta">录于 ${esc(when)} · 用浏览器打开本文件即可，不需要安装任何软件</p>` : `<p class="meta">用浏览器打开本文件即可，不需要安装任何软件</p>`}
    </header>
    <div class="toolbar">
      <button type="button" id="play">演示一遍</button>
      <a class="ghost" href="#s0">从第一步看</a>
    </div>
    ${cards.join("\n") || "<p>还没有步骤。</p>"}
    <p class="foot">本手册由「录技」浏览器扩展根据真实操作生成。演示只是带着看步骤，不会自动登录别人的账号。</p>
  </div>
  <div id="stage" aria-modal="true">
    <div class="frame">
      <div class="pic">
        <img id="stage-img" alt="" />
        <i class="pin" id="stage-pin"></i>
      </div>
      <p class="empty" id="stage-empty">这一步没有截图</p>
    </div>
    <div class="cap">
      <strong id="stage-title"></strong>
      <span id="stage-body"></span>
    </div>
    <div class="bar">
      <button type="button" id="prev">上一步</button>
      <button type="button" id="pause">暂停</button>
      <button type="button" id="next">下一步</button>
      <button type="button" id="close">退出演示</button>
    </div>
  </div>
  <script>
    const STEPS = ${JSON.stringify(demo)};
    let i = 0, timer = 0, playing = false;
    const stage = document.getElementById("stage");
    const img = document.getElementById("stage-img");
    const empty = document.getElementById("stage-empty");
    const pin = document.getElementById("stage-pin");
    const titleEl = document.getElementById("stage-title");
    const bodyEl = document.getElementById("stage-body");
    const pauseBtn = document.getElementById("pause");

    function show(n) {
      i = (n + STEPS.length) % STEPS.length;
      const s = STEPS[i];
      titleEl.textContent = (i + 1) + " / " + STEPS.length + "  " + s.title;
      bodyEl.textContent = s.body;
      if (s.shot) {
        img.src = s.shot;
        img.style.display = "block";
        empty.style.display = "none";
      } else {
        img.removeAttribute("src");
        img.style.display = "none";
        empty.style.display = "block";
      }
      if (typeof s.xPct === "number" && typeof s.yPct === "number") {
        pin.style.display = "block";
        pin.style.left = s.xPct + "%";
        pin.style.top = s.yPct + "%";
      } else {
        pin.style.display = "none";
      }
    }
    function stopTimer() { clearInterval(timer); timer = 0; }
    function play() {
      playing = true;
      pauseBtn.textContent = "暂停";
      stopTimer();
      timer = setInterval(() => {
        if (i >= STEPS.length - 1) { pause(); return; }
        show(i + 1);
      }, 2400);
    }
    function pause() {
      playing = false;
      pauseBtn.textContent = "继续";
      stopTimer();
    }
    function openStage() {
      stage.classList.add("on");
      show(0);
      play();
    }
    document.getElementById("play").onclick = openStage;
    document.getElementById("close").onclick = () => { pause(); stage.classList.remove("on"); };
    document.getElementById("next").onclick = () => { pause(); show(i + 1); };
    document.getElementById("prev").onclick = () => { pause(); show(i - 1); };
    pauseBtn.onclick = () => (playing ? pause() : play());
    document.addEventListener("keydown", (e) => {
      if (!stage.classList.contains("on")) return;
      if (e.key === "Escape") { pause(); stage.classList.remove("on"); }
      if (e.key === "ArrowRight") { pause(); show(i + 1); }
      if (e.key === "ArrowLeft") { pause(); show(i - 1); }
    });
  </script>
</body>
</html>
`;
  }

  function buildPack({ name, description, steps, shots, recordedAt }) {
    const Clean = getClean();
    const filename = Clean.fileTitle(name);
    const html = buildManualHtml({ name, description, steps, shots, recordedAt });
    return { filename, html };
  }

  return { buildPack, buildManualHtml };
});
