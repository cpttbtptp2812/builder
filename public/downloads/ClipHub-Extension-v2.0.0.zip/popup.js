function escapeHtml(t) {
  return String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

document.querySelectorAll(".tab").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((b) => b.classList.remove("on"));
    document.querySelectorAll(".panel").forEach((p) => p.classList.remove("on"));
    btn.classList.add("on");
    document.getElementById(`panel-${btn.dataset.tab}`).classList.add("on");
  });
});

async function loadClips() {
  const hint = document.getElementById("clip-hint");
  const list = document.getElementById("clip-list");
  let items = [];
  try {
    const res = await chrome.runtime.sendMessage({ type: "list" });
    items = res?.items || [];
  } catch { /* ignore */ }

  if (!items.length) {
    hint.style.display = "block";
    list.innerHTML = '<li class="empty">暂无摘录</li>';
    return;
  }
  hint.style.display = "none";
  list.innerHTML = items.map((item) => `<li><button type="button" data-id="${item.id}">
    <strong>${escapeHtml(item.title || "摘录")}</strong>
    <span>${escapeHtml(item.content?.slice(0, 80) || "")}</span>
  </button></li>`).join("");

  const map = new Map(items.map((i) => [i.id, i]));
  list.querySelectorAll("button[data-id]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const item = map.get(btn.dataset.id);
      if (!item) return;
      const r = await chrome.runtime.sendMessage({ type: "jump", item });
      if (!r?.ok) hint.textContent = r?.error || "跳转失败";
    });
  });
}

async function loadWatches() {
  const list = document.getElementById("watch-list");
  let items = [];
  try {
    const res = await chrome.runtime.sendMessage({ type: "watch-list" });
    items = res?.items || [];
  } catch { /* ignore */ }

  if (!items.length) {
    list.innerHTML = '<li class="empty">暂无监控<br/>在商品页右键「监控此商品」</li>';
    return;
  }

  list.innerHTML = items.map((w) => {
    const img = w.image ? `<img src="${escapeHtml(w.image)}" alt="" />` : '<div style="width:48px;height:48px;background:#e2e8f0;border-radius:6px"></div>';
    const price = w.price || (w.priceNum != null ? `¥${w.priceNum}` : "—");
    return `<li class="watch-item" data-id="${w.id}">
      ${img}
      <div>
        <strong>${escapeHtml(w.title?.slice(0, 36) || "未命名")}</strong>
        <span class="sub">${escapeHtml(w.site)} · ${w.kind === "product" ? "商品" : "页面"}</span>
        <span class="price">${escapeHtml(price)}</span>
      </div>
      <div class="actions">
        <button type="button" class="open">打开</button>
        <button type="button" class="del">删</button>
      </div>
    </li>`;
  }).join("");

  items.forEach((w) => {
    const row = list.querySelector(`[data-id="${w.id}"]`);
    row?.querySelector(".open")?.addEventListener("click", () => {
      chrome.runtime.sendMessage({ type: "open-watch", url: w.url });
    });
    row?.querySelector(".del")?.addEventListener("click", async () => {
      await chrome.runtime.sendMessage({ type: "watch-remove", id: w.id });
      loadWatches();
    });
  });
}

document.getElementById("btn-read").addEventListener("click", async () => {
  const msg = document.getElementById("read-msg");
  msg.textContent = "";
  try {
    const r = await chrome.runtime.sendMessage({ type: "focus-active-tab", theme: "dark" });
    if (!r?.ok) msg.textContent = r?.error || "无法开启，请刷新目标页";
    else window.close();
  } catch {
    msg.textContent = "请刷新页面后重试";
  }
});

loadClips();
loadWatches();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.clipHubSnippets) loadClips();
  if (changes.clipHubWatches) loadWatches();
});
