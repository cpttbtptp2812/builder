/** 页面 / 商品解析 — 淘宝、天猫、京东、通用 */

export function parsePriceNum(text) {
  if (!text) return null;
  const m = String(text).replace(/,/g, "").match(/(\d+(?:\.\d+)?)/);
  return m ? Number(m[1]) : null;
}

export function normalizeWatchUrl(url) {
  try {
    const u = new URL(url);
    u.hash = "";
    if (/taobao\.com|tmall\.com/.test(u.hostname)) {
      const id = u.searchParams.get("id");
      if (id) return `${u.origin}${u.pathname}?id=${id}`;
    }
    if (/jd\.com/.test(u.hostname)) {
      const m = u.pathname.match(/(\d+)\.html/);
      if (m) return `https://${u.hostname}/${m[1]}.html`;
    }
    return u.origin + u.pathname + u.search;
  } catch {
    return url.split("#")[0];
  }
}

export function detectSite(host) {
  if (/taobao\.com/.test(host)) return "taobao";
  if (/tmall\.com/.test(host)) return "tmall";
  if (/jd\.com/.test(host)) return "jd";
  if (/amazon\./.test(host)) return "amazon";
  return "generic";
}

function pickText(selectors, root = document) {
  for (const sel of selectors) {
    const el = root.querySelector(sel);
    const t = el?.textContent?.trim();
    if (t) return t;
  }
  return "";
}

function pickAttr(selectors, attr, root = document) {
  for (const sel of selectors) {
    const el = root.querySelector(sel);
    const v = el?.getAttribute?.(attr);
    if (v) return v;
  }
  return "";
}

/** 在页面上下文中执行 — 也可通过 executeScript 调用 */
export function extractProductFromDocument(doc = document, loc = location) {
  const site = detectSite(loc.hostname);
  let title = "";
  let price = "";
  let image = "";
  let productUrl = normalizeWatchUrl(loc.href);

  if (site === "taobao" || site === "tmall") {
    title = pickText([
      "h1",
      "[class*='MainTitle']",
      "[class*='ItemHeader'] h1",
      ".tb-main-title",
      "#J_Title h1",
    ], doc);
    price = pickText([
      "[class*='Price--priceText']",
      "[class*='tm-price']",
      ".tb-rmb-num",
      "#J_StrPrice",
      "[class*='priceWrap']",
    ], doc);
    image = pickAttr(["meta[property='og:image']"], "content", doc)
      || pickAttr(["#J_ImgBooth", "[class*='mainPic'] img"], "src", doc);
  } else if (site === "jd") {
    title = pickText([".sku-name", ".itemInfo-wrap .sku-name", "h1"], doc);
    price = pickText([".price", ".p-price .price", "[class*='PricePrice']"], doc);
    image = pickAttr(["meta[property='og:image']"], "content", doc)
      || pickAttr(["#spec-img", ".jqzoom img"], "src", doc);
  } else {
    title = pickAttr(["meta[property='og:title']"], "content", doc) || doc.title || "";
    price = pickAttr(["meta[property='product:price:amount']"], "content", doc)
      || pickText(["[itemprop='price']", ".price", ".product-price"], doc);
    image = pickAttr(["meta[property='og:image']"], "content", doc);
  }

  title = title.replace(/\s+/g, " ").trim().slice(0, 120);
  price = price.replace(/\s+/g, " ").trim().slice(0, 32);
  const priceNum = parsePriceNum(price);
  const isProduct = Boolean(
    (site !== "generic" && (title || priceNum)) ||
    (priceNum && /商品|product|item/i.test(loc.pathname + doc.title)),
  );

  return {
    site,
    kind: isProduct ? "product" : "page",
    title: title || doc.title?.slice(0, 80) || loc.hostname,
    price: price || (priceNum != null ? `¥${priceNum}` : null),
    priceNum,
    image,
    url: productUrl,
  };
}

export function urlMatchesWatch(pageUrl, watchUrl) {
  return normalizeWatchUrl(pageUrl) === normalizeWatchUrl(watchUrl);
}
