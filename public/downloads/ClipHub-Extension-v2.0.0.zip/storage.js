const SNIPPET_KEY = "clipHubSnippets";
const WATCH_KEY = "clipHubWatches";

export async function getLocalSnippets() {
  const { [SNIPPET_KEY]: items } = await chrome.storage.local.get(SNIPPET_KEY);
  return Array.isArray(items) ? items : [];
}

export async function setLocalSnippets(items) {
  await chrome.storage.local.set({ [SNIPPET_KEY]: items });
}

export async function addLocalSnippet(snippet) {
  const items = await getLocalSnippets();
  items.unshift(snippet);
  await setLocalSnippets(items);
  return snippet;
}

export async function getWatches() {
  const { [WATCH_KEY]: items } = await chrome.storage.local.get(WATCH_KEY);
  return Array.isArray(items) ? items : [];
}

export async function setWatches(items) {
  await chrome.storage.local.set({ [WATCH_KEY]: items.slice(0, 100) });
}

export async function addWatch(entry) {
  const items = await getWatches();
  const norm = entry.url;
  const idx = items.findIndex((w) => w.url === norm);
  if (idx >= 0) {
    items[idx] = { ...items[idx], ...entry, updatedAt: new Date().toISOString() };
  } else {
    items.unshift(entry);
  }
  await setWatches(items);
  return entry;
}

export async function removeWatch(id) {
  const items = (await getWatches()).filter((w) => w.id !== id);
  await setWatches(items);
}

export async function updateWatchPrice(id, price, priceNum) {
  const items = await getWatches();
  const w = items.find((x) => x.id === id);
  if (!w) return null;
  const history = Array.isArray(w.history) ? w.history : [];
  if (w.priceNum != null && priceNum != null && w.priceNum !== priceNum) {
    history.unshift({ price, priceNum, at: new Date().toISOString() });
  } else if (w.priceNum == null && priceNum != null) {
    history.unshift({ price, priceNum, at: new Date().toISOString() });
  }
  w.price = price;
  w.priceNum = priceNum;
  w.history = history.slice(0, 20);
  w.lastCheckedAt = new Date().toISOString();
  await setWatches(items);
  return w;
}

export async function canSyncDesktop() {
  const token = (await chrome.storage.local.get("clipHubToken")).clipHubToken;
  if (!token) return false;
  try {
    const r = await fetch("http://127.0.0.1:38472/health", {
      headers: { "X-Clip-Token": token },
    });
    return r.ok;
  } catch {
    return false;
  }
}
