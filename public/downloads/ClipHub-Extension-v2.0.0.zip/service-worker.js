import { buildJumpUrl } from "./jump.js";
import { normalizeWatchUrl } from "./page-parse.js";
import {
  addLocalSnippet,
  addWatch,
  canSyncDesktop,
  getLocalSnippets,
  getWatches,
  removeWatch,
  setLocalSnippets,
  updateWatchPrice,
} from "./storage.js";

const API = "http://127.0.0.1:38472";

async function getToken() {
  const { clipHubToken } = await chrome.storage.local.get("clipHubToken");
  return clipHubToken || "";
}

async function api(path, options = {}) {
  const token = await getToken();
  const res = await fetch(`${API}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "X-Clip-Token": token,
      ...(options.headers || {}),
    },
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `请求失败 ${res.status}`);
  return data;
}

async function notify(title, message) {
  try {
    await chrome.notifications.create(`clip-hub-${Date.now()}`, {
      type: "basic",
      title,
      message,
      priority: 2,
    });
  } catch {
    /* ignore */
  }
}

async function syncToDesktop(snippet) {
  if (!(await canSyncDesktop())) return snippet;
  try {
    return await api("/snippets", { method: "POST", body: JSON.stringify(snippet) });
  } catch {
    return snippet;
  }
}

async function capturePageAnchor(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const sel = window.getSelection();
      let scrollY = window.scrollY;
      if (sel?.rangeCount) {
        const rect = sel.getRangeAt(0).getBoundingClientRect();
        if (rect.height > 0 || rect.width > 0) {
          scrollY = Math.round(window.scrollY + rect.top - window.innerHeight * 0.3);
        }
      }
      return {
        scrollY,
        pageUrl: location.href.split("#")[0],
        pageTitle: document.title,
      };
    },
  });
  return result;
}

function buildWatchEntry(data) {
  return {
    id: crypto.randomUUID(),
    kind: data.kind || "page",
    site: data.site || "generic",
    title: data.title,
    url: normalizeWatchUrl(data.url),
    price: data.price ?? null,
    priceNum: data.priceNum ?? null,
    image: data.image ?? null,
    history: data.priceNum != null ? [{ price: data.price, priceNum: data.priceNum, at: new Date().toISOString() }] : [],
    createdAt: new Date().toISOString(),
    lastCheckedAt: new Date().toISOString(),
    note: data.note || "",
  };
}

function setupMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: "clip-save", title: "ClipHub · 保存选中摘录", contexts: ["selection"] });
    chrome.contextMenus.create({ id: "clip-read", title: "ClipHub · 阅读此页", contexts: ["page"] });
    chrome.contextMenus.create({ id: "clip-watch-page", title: "ClipHub · 监控此页面", contexts: ["page"] });
    chrome.contextMenus.create({ id: "clip-watch-product", title: "ClipHub · 监控此商品", contexts: ["page"] });
    chrome.contextMenus.create({ id: "clip-watch-selection", title: "ClipHub · 监控选中内容", contexts: ["selection"] });
  });
}

chrome.runtime.onInstalled.addListener(setupMenus);
chrome.runtime.onStartup.addListener(setupMenus);

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab?.id) return;

  if (info.menuItemId === "clip-save" && info.selectionText) {
    let anchor = { scrollY: null, pageUrl: tab.url?.split("#")[0] || "", pageTitle: tab.title || "" };
    try {
      anchor = await capturePageAnchor(tab.id);
    } catch { /* ignore */ }

    await addLocalSnippet({
      id: crypto.randomUUID(),
      title: anchor.pageTitle?.slice(0, 40) || "摘录",
      content: info.selectionText,
      pageUrl: anchor.pageUrl || tab.url?.split("#")[0] || "",
      pageTitle: anchor.pageTitle || tab.title || "",
      scrollY: anchor.scrollY ?? null,
      createdAt: new Date().toISOString(),
    });
    await notify("ClipHub", "摘录已保存");
    return;
  }

  if (info.menuItemId === "clip-read") {
    chrome.tabs.sendMessage(tab.id, { type: "focus-toggle", theme: "dark" }).catch(() => {
      notify("ClipHub", "无法开启阅读模式，请刷新页面");
    });
    return;
  }

  if (info.menuItemId === "clip-watch-page" || info.menuItemId === "clip-watch-product") {
    let data;
    try {
      const res = await chrome.tabs.sendMessage(tab.id, { type: "extract-product" });
      data = res?.product;
    } catch { /* ignore */ }
    if (!data) {
      data = { kind: "page", site: "generic", title: tab.title, url: tab.url, price: null, priceNum: null };
    }
    if (info.menuItemId === "clip-watch-page") data.kind = "page";
    else data.kind = "product";
    const entry = buildWatchEntry(data);
    await addWatch(entry);
    await notify("ClipHub · 监控", entry.kind === "product" ? `${entry.title.slice(0, 20)} · ${entry.price || "已加入"}` : "已监控此页面");
    return;
  }

  if (info.menuItemId === "clip-watch-selection" && info.selectionText) {
    const text = info.selectionText.trim();
    const num = Number(String(text).replace(/[^\d.]/g, ""));
    await addWatch(buildWatchEntry({
      kind: "snippet",
      site: "selection",
      title: text.slice(0, 60),
      url: normalizeWatchUrl(tab.url || ""),
      price: /[\d]/.test(text) ? text.slice(0, 24) : null,
      priceNum: Number.isFinite(num) && num > 0 ? num : null,
      note: text,
    }));
    await notify("ClipHub", "已监控选中内容");
  }
});

async function sendJumpToTab(tabId, item, attempt = 0) {
  try {
    await chrome.tabs.sendMessage(tabId, { type: "clip-hub-jump", scrollY: item.scrollY ?? null, text: item.content || "" });
    return true;
  } catch {
    if (attempt >= 6) return false;
    await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
    return sendJumpToTab(tabId, item, attempt + 1);
  }
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === "list") {
    (async () => {
      let items = await getLocalSnippets();
      let synced = false;
      if (await canSyncDesktop()) {
        try {
          const data = await api("/snippets");
          items = data.items?.length ? data.items : items;
          await setLocalSnippets(items);
          synced = true;
        } catch { /* local */ }
      }
      sendResponse({ ok: true, items, synced });
    })();
    return true;
  }

  if (msg.type === "watch-list") {
    getWatches().then((items) => sendResponse({ ok: true, items }));
    return true;
  }

  if (msg.type === "watch-remove") {
    removeWatch(msg.id).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "watch-price-update") {
    updateWatchPrice(msg.id, msg.price, msg.priceNum).then((w) => sendResponse({ ok: true, watch: w }));
    return true;
  }

  if (msg.type === "jump") {
    (async () => {
      const url = buildJumpUrl(msg.item);
      if (!url) {
        sendResponse({ ok: false, error: "无法跳转" });
        return;
      }
      const tab = await chrome.tabs.create({ url });
      await new Promise((resolve) => {
        const fn = (id, info) => {
          if (id === tab.id && info.status === "complete") {
            chrome.tabs.onUpdated.removeListener(fn);
            resolve();
          }
        };
        chrome.tabs.onUpdated.addListener(fn);
      });
      await sendJumpToTab(tab.id, msg.item);
      sendResponse({ ok: true });
    })();
    return true;
  }

  if (msg.type === "open-watch") {
    chrome.tabs.create({ url: msg.url }).then(() => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "focus-active-tab") {
    chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
      if (!tab?.id) {
        sendResponse({ ok: false });
        return;
      }
      chrome.tabs.sendMessage(tab.id, { type: "focus-toggle", theme: msg.theme || "dark" })
        .then((r) => sendResponse(r))
        .catch(() => sendResponse({ ok: false, error: "请刷新页面" }));
    });
    return true;
  }

  if (msg.type === "ping") {
    canSyncDesktop().then((synced) => sendResponse({ ok: true, synced }));
    return true;
  }
});
