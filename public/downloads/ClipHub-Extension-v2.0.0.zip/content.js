import {
  extractProductFromDocument,
  normalizeWatchUrl,
  urlMatchesWatch,
} from "./page-parse.js";

/** Clip 跳回 + 阅读模式 + 商品监控 */
(function () {
  const HIGHLIGHT_STYLE = "clip-hub-highlight";
  const STYLE_ID = "clip-hub-highlight-style";
  const ROOT_ID = "focus-reader-root";
  const READER_STYLE_ID = "focus-reader-style";

  /* —— Clip 跳回 —— */
  function ensureHighlightStyle() {
    if (document.getElementById(STYLE_ID)) return;
    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      mark.${HIGHLIGHT_STYLE} {
        background: rgba(94, 234, 212, 0.45) !important;
        outline: 2px solid #0d9488;
        border-radius: 2px;
      }
    `;
    document.documentElement.appendChild(style);
  }

  function normalizeText(text) {
    return String(text).replace(/\s+/g, " ").trim();
  }

  function jumpByText(text, scrollY) {
    ensureHighlightStyle();
    const needles = [normalizeText(text).slice(0, 120)].filter(Boolean);
    if (!needles.length) return false;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    let node;
    while ((node = walker.nextNode())) {
      if (!node.textContent || node.parentElement?.closest("script, style")) continue;
      for (const needle of needles) {
        const idx = node.textContent.indexOf(needle);
        if (idx < 0) continue;
        try {
          const range = document.createRange();
          range.setStart(node, idx);
          range.setEnd(node, idx + needle.length);
          const mark = document.createElement("mark");
          mark.className = HIGHLIGHT_STYLE;
          range.surroundContents(mark);
          mark.scrollIntoView({ block: "center", behavior: "smooth" });
          return true;
        } catch { /* continue */ }
      }
    }
    if (scrollY != null) {
      window.scrollTo({ top: Number(scrollY), behavior: "smooth" });
      return true;
    }
    return false;
  }

  function applyJump(payload, tries = 8) {
    if (jumpByText(payload.text || "", payload.scrollY)) return;
    if (tries <= 0) return;
    setTimeout(() => applyJump(payload, tries - 1), 350);
  }

  /* —— 阅读模式 —— */
  function extractArticle() {
    for (const sel of ["article", "[role=main]", "main", ".post-content", ".article-content", "#content"]) {
      const el = document.querySelector(sel);
      if (el && (el.innerText || "").trim().length > 400) return el.cloneNode(true);
    }
    const ps = [...document.querySelectorAll("p")];
    let best = null, bestScore = 0;
    for (const p of ps) {
      const el = p.closest("div, section, article") || p;
      if (el.closest("nav, header, footer, aside")) continue;
      const score = (el.innerText || "").length;
      if (score > bestScore) { best = el; bestScore = score; }
    }
    return best ? best.cloneNode(true) : null;
  }

  function enableReader(theme = "dark") {
    if (document.getElementById(ROOT_ID)) return { ok: true };
    const article = extractArticle();
    if (!article) return { ok: false, error: "未找到可读正文" };

    document.documentElement.classList.add("focus-reader-active");
    const root = document.createElement("div");
    root.id = ROOT_ID;
    root.className = `focus-theme-${theme}`;
    root.innerHTML = `
      <header class="focus-bar">
        <strong>ClipHub 阅读</strong>
        <button type="button" id="focus-theme-toggle">${theme === "light" ? "深色" : "浅色"}</button>
        <button type="button" id="focus-close">退出</button>
      </header>
      <article class="focus-body"></article>
    `;
    root.querySelector(".focus-body").appendChild(article);
    document.body.appendChild(root);
    root.querySelector("#focus-close").onclick = disableReader;
    root.querySelector("#focus-theme-toggle").onclick = () => {
      const next = root.classList.contains("focus-theme-light") ? "dark" : "light";
      disableReader();
      enableReader(next);
    };
    return { ok: true };
  }

  function disableReader() {
    document.getElementById(ROOT_ID)?.remove();
    document.documentElement.classList.remove("focus-reader-active");
    return { ok: true };
  }

  /* —— 监控 toast —— */
  function showToast(html) {
    const el = document.createElement("div");
    el.className = "clip-hub-toast";
    el.innerHTML = html;
    document.body.appendChild(el);
    setTimeout(() => el.classList.add("on"), 10);
    setTimeout(() => { el.classList.remove("on"); setTimeout(() => el.remove(), 300); }, 4500);
  }

  async function checkWatchPrices() {
    const res = await chrome.runtime.sendMessage({ type: "watch-list" });
    const watches = res?.items || [];
    const here = normalizeWatchUrl(location.href);
    const match = watches.find((w) => urlMatchesWatch(location.href, w.url) || w.url === here);
    if (!match || match.kind !== "product") return;

    const fresh = extractProductFromDocument();
    if (fresh.priceNum == null) return;

    if (match.priceNum != null && fresh.priceNum !== match.priceNum) {
      const diff = fresh.priceNum - match.priceNum;
      const arrow = diff < 0 ? "↓ 降价" : "↑ 涨价";
      const delta = Math.abs(diff).toFixed(2);
      showToast(`<strong>ClipHub 监控</strong><span>${arrow} ¥${delta}</span><em>${fresh.price}（原 ${match.price}）</em>`);
      try {
        await chrome.runtime.sendMessage({
          type: "watch-price-update",
          id: match.id,
          price: fresh.price,
          priceNum: fresh.priceNum,
        });
      } catch { /* ignore */ }
    } else if (match.priceNum == null) {
      await chrome.runtime.sendMessage({
        type: "watch-price-update",
        id: match.id,
        price: fresh.price,
        priceNum: fresh.priceNum,
      });
    }
  }

  chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg.type === "clip-hub-jump") {
      applyJump({ scrollY: msg.scrollY, text: msg.text || "" });
      return;
    }
    if (msg.type === "focus-toggle") {
      sendResponse(document.getElementById(ROOT_ID) ? disableReader() : enableReader(msg.theme || "dark"));
      return true;
    }
    if (msg.type === "focus-status") {
      sendResponse({ active: Boolean(document.getElementById(ROOT_ID)) });
      return;
    }
    if (msg.type === "extract-product") {
      sendResponse({ product: extractProductFromDocument() });
      return;
    }
  });

  setTimeout(checkWatchPrices, 1200);
})();
