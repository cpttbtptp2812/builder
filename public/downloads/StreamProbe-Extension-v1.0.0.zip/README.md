# StreamProbe Chrome Extension

> AI 与流式 API 的浏览器端调试器 · **个人开源项目**

完整产品与技术规格见：[docs/streamprobe/PRODUCT.md](../../docs/streamprobe/PRODUCT.md)

## 状态

🚧 **规划中** — MVP 开发尚未开始。当前联调工具包内的 Wire 面板为早期原型，StreamProbe 将独立成扩展并支持 fetch stream、Side Panel、协议解析与导出。

## 计划能力

- EventSource + fetch ReadableStream 帧级捕获
- Side Panel 时间线、TTFB / 帧间隔
- SSE / AI SDK Raw ↔ Parsed 双栏
- 导出 `.streamprobe.json`

## 简历文案

见 [docs/streamprobe/RESUME.md](../../docs/streamprobe/RESUME.md)
